'use client'
import { useState } from 'react'

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState('admin')
  const [records, setRecords] = useState<any[]>([])
  const [surveyLink, setSurveyLink] = useState('https://example.com/survey')

  const addRecord = (name: string) => {
    setRecords([...records, { id: Date.now(), name, status: 'Pending' }])
  }

  const markComplete = (id: number) => {
    setRecords(records.map(r => r.id === id ? { ...r, status: 'Completed' } : r))
  }

  const deleteRecord = (id: number) => {
    setRecords(records.filter(r => r.id !== id))
  }

  return (
    <div style={{ background: 'white', padding: 20, borderRadius: 10, boxShadow: '0 2px 6px rgba(0,0,0,0.1)' }}>
      <h1>Survey Dashboard</h1>
      <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
        <button onClick={() => setActiveTab('admin')}>Admin Panel</button>
        <button onClick={() => setActiveTab('prescreener')}>Prescreener</button>
        <button onClick={() => setActiveTab('records')}>Survey Records</button>
        <button onClick={() => setActiveTab('link')}>Change Link</button>
      </div>

      {activeTab === 'admin' && (
        <div>
          <h2>Admin Panel</h2>
          <p>Welcome to the admin panel. Manage surveys and data here.</p>
        </div>
      )}

      {activeTab === 'prescreener' && (
        <div>
          <h2>Prescreener</h2>
          <input id="nameInput" placeholder="Enter participant name" />
          <button onClick={() => {
            const input = document.getElementById('nameInput') as HTMLInputElement
            if (input.value) { addRecord(input.value); input.value = '' }
          }}>Add</button>
        </div>
      )}

      {activeTab === 'records' && (
        <div>
          <h2>Survey Records</h2>
          <ul>
            {records.map(r => (
              <li key={r.id}>
                {r.name} - {r.status}
                {r.status === 'Pending' && <button onClick={() => markComplete(r.id)}>Mark Completed</button>}
                <button onClick={() => deleteRecord(r.id)}>Delete</button>
              </li>
            ))}
          </ul>
        </div>
      )}

      {activeTab === 'link' && (
        <div>
          <h2>Change Survey Link</h2>
          <input value={surveyLink} onChange={(e) => setSurveyLink(e.target.value)} />
          <p>Current Link: <a href={surveyLink} target="_blank">{surveyLink}</a></p>
        </div>
      )}
    </div>
  )
}