export const metadata = {
  title: 'Survey Dashboard',
  description: 'Admin + Prescreener + Records + Link Change',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: 'sans-serif', margin: 0, padding: 20, background: '#f4f4f4' }}>
        {children}
      </body>
    </html>
  )
}