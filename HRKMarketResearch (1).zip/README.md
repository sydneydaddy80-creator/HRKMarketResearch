# HRKMarketResearch Dashboard

This is a simple survey dashboard admin panel.